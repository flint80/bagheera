package app.iui.command;

/**
 * @author Igor Usenko
 *         Date: 01.05.2010
 */
public interface Command {
    void execute();
}
