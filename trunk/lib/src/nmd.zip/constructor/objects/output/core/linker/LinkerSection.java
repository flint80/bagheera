package constructor.objects.output.core.linker;

/**
 * @author Igor Usenko
 *         Date: 27.02.2011
 */
public interface LinkerSection {
}
