package converter.format.fb2;

/**
 * @author Igor Usenko
 *         Date: 31.08.2008
 */
public interface Stringable {

    String[] getStrings();
}
