package converter.format.fb2.resource;

/**
 * @author Igor Usenko
 *         Date: 06.09.2008
 */
public enum Fb2ResourceFileType {
    COMPATIBLE, CONVERTIBLE, NOT_SUPPORTED
}
