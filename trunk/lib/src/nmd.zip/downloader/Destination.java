package downloader;

/**
 * @author Igor Usenko
 *         Date: 25.09.2008
 */
public enum Destination {
    FILE, MEMORY
}
