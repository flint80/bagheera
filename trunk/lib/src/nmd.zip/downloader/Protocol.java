package downloader;

/**
 * @author Igor Usenko
 *         Date: 27.09.2008
 */
public enum Protocol {
    HOST, HTTP, UNKNOWN
}
